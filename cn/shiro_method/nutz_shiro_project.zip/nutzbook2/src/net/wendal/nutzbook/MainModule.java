package net.wendal.nutzbook;

import org.nutz.integration.shiro.ShiroSessionProvider;
import org.nutz.mvc.annotation.Fail;
import org.nutz.mvc.annotation.IocBy;
import org.nutz.mvc.annotation.Modules;
import org.nutz.mvc.annotation.Ok;
import org.nutz.mvc.annotation.SessionBy;
import org.nutz.mvc.annotation.SetupBy;

@IocBy(args={"*js", "ioc/",
             "*anno", "net.wendal.nutzbook",
             "*tx",
             "*async"})
@Modules(scanPackage=true)
@SetupBy(MainSetup.class)
@Ok("json")
@Fail("http:500")
@SessionBy(ShiroSessionProvider.class)
public class MainModule {


}

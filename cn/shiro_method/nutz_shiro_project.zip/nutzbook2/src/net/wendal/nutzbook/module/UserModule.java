package net.wendal.nutzbook.module;

import javax.servlet.http.HttpSession;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.crypto.hash.Sha256Hash;
import org.nutz.dao.Dao;
import org.nutz.integration.shiro.SimpleShiroToken;
import org.nutz.ioc.loader.annotation.Inject;
import org.nutz.ioc.loader.annotation.IocBean;
import org.nutz.lang.Strings;
import org.nutz.log.Log;
import org.nutz.log.Logs;
import org.nutz.mvc.annotation.At;
import org.nutz.mvc.annotation.Attr;
import org.nutz.mvc.annotation.GET;
import org.nutz.mvc.annotation.Ok;
import org.nutz.mvc.annotation.POST;

import net.wendal.nutzbook.bean.User;

@At("/user")
@IocBean
public class UserModule {
    
    private static final Log log = Logs.get();

    @Inject
    protected Dao dao;
    
    @At
    public int count() {
        return dao.count(User.class);
    }
    
    @GET
    @At("/login")
    @Ok("jsp:jsp.login")
    public void loginPage() {}

    @POST
    @At
    public boolean login(String username, String password, HttpSession session) {
        if (Strings.isBlank(username) || Strings.isBlank(password)) {
            log.debug("username or password is null");
            return false;
        }
        User user = dao.fetch(User.class, username);
        if (user == null) {
            log.debug("no such user = " + username);
            return false;
        }
        String tmp = new Sha256Hash(password, user.getSalt()).toHex();
        if (!tmp.equals(user.getPassword())) {
            log.debug("password is wrong");
            return false;
        }
        SecurityUtils.getSubject().login(new SimpleShiroToken(user.getId()));
        session.setAttribute("me", user);
        return true;
    }
    
    @At
    @Ok("json:{locked:'password|salt'}")
    public User me(@Attr("me")User user) {
        return user;
    }
}

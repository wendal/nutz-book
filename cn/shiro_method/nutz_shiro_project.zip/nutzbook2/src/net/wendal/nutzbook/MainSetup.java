package net.wendal.nutzbook;

import org.apache.shiro.crypto.hash.Sha256Hash;
import org.nutz.dao.Dao;
import org.nutz.dao.util.Daos;
import org.nutz.ioc.Ioc;
import org.nutz.lang.random.R;
import org.nutz.mvc.NutConfig;
import org.nutz.mvc.Setup;

import net.wendal.nutzbook.bean.User;

public class MainSetup implements Setup {

    @Override
    public void init(NutConfig nc) {
        Ioc ioc = nc.getIoc();
        Dao dao = ioc.get(Dao.class);
        Daos.createTablesInPackage(dao, getClass(), false);
        
        if (0 == dao.count(User.class)) {
            User user = new User();
            user.setName("admin");
            user.setSalt(R.UU32());
            user.setPassword(new Sha256Hash("123456", user.getSalt()).toHex());
            dao.insert(user);
        }
    }

    @Override
    public void destroy(NutConfig nc) {}

}
